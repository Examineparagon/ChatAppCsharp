﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatAppV9
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void txtMsg_Click(object sender, EventArgs e)
        {
            //DAL this 
            ///Send msg, store in text, pk to fk , join id col from login and show username
            ///and msg in write prot 
        }
    }
}
